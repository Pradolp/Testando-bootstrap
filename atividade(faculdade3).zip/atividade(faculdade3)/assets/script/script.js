const nome = 'Lucas';
const arrNome = nome.split('');
const nomeSize = nome.length - 1;
let reverse = [];

for(let i = nomeSize; i >= 0; i--){
   reverse.push(nome[i]);
}

console.log(reverse.join(''));
